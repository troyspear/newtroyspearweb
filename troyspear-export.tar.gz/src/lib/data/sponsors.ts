export interface Sponsor {
  name: string
  logo: string
  url: string
  tier: 'platinum' | 'gold' | 'silver' | 'bronze'
}

export const sponsors: Sponsor[] = [
  { name: 'Water Linked', logo: '/images/sponsors/waterlinked.png', url: 'https://waterlinked.com', tier: 'platinum' },
  { name: 'SimScale', logo: '/images/sponsors/simscale.png', url: 'https://simscale.com', tier: 'gold' },
  { name: 'Onshape', logo: '/images/sponsors/onshape.png', url: 'https://onshape.com', tier: 'silver' },
  { name: 'Blue Robotics', logo: '/images/sponsors/bluerobotics.png', url: 'https://bluerobotics.com', tier: 'bronze' },
  { name: 'Blue Trail Engineering', logo: '/images/sponsors/bluetrail.png', url: 'https://bluetrailengineering.com', tier: 'bronze' },
]

export const tierConfig = {
  platinum: { label: 'Platinum', logoSize: 'h-20' },
  gold: { label: 'Gold', logoSize: 'h-16' },
  silver: { label: 'Silver', logoSize: 'h-14' },
  bronze: { label: 'Bronze', logoSize: 'h-12' },
}
