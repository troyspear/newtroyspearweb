'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function HeroSection() {
  return (
    <section className="relative min-h-[85vh] flex items-end px-5 sm:px-8 pb-20">
      <div className="relative z-10 max-w-6xl mx-auto w-full">
        <p className="text-[11px] tracking-[0.2em] uppercase text-fg-muted mb-6">
          Troy High School &middot; Underwater Robotics
        </p>
        <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-light text-fg leading-[1.1] tracking-tight max-w-3xl">
          Engineering autonomous<br className="hidden sm:block" /> underwater vehicles
        </h1>
        <p className="mt-6 text-fg-secondary text-base max-w-lg leading-relaxed">
          Competing in RoboNation RoboSub. Student-designed,
          student-built, from hull to software.
        </p>
        <div className="mt-10">
          <Link
            href="/vehicle"
            className="inline-flex items-center gap-2 text-sm font-medium text-accent hover:opacity-70 transition-opacity"
          >
            View our vehicle
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </section>
  )
}
