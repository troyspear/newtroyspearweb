import type { Metadata } from 'next'
import Image from 'next/image'
import { Mail } from 'lucide-react'
import { sponsors, tierConfig } from '@/lib/data/sponsors'

export const metadata: Metadata = {
  title: 'Sponsors',
  description: 'Our sponsors make Troy SPEAR possible. Learn how to support our team.',
}

export default function SponsorsPage() {
  const tiers = ['platinum', 'gold', 'silver', 'bronze'] as const

  return (
    <div className="pt-20 pb-16">
      <section className="px-5 sm:px-8 py-16">
        <div className="max-w-6xl mx-auto">
          <h1 className="font-display text-2xl sm:text-3xl font-light text-fg tracking-tight">
            Sponsors
          </h1>
          <p className="mt-3 text-sm text-fg-muted max-w-lg">
            The organizations and individuals who make our work possible.
          </p>

          <div className="mt-14 space-y-12">
            {tiers.map((tier) => {
              const tierSponsors = sponsors.filter((s) => s.tier === tier)
              if (tierSponsors.length === 0) return null
              const config = tierConfig[tier]

              return (
                <div key={tier}>
                  <h3 className="text-xs font-medium text-fg-muted uppercase tracking-wide mb-4">
                    {config.label}
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {tierSponsors.map((sponsor) => (
                      <a
                        key={sponsor.name}
                        href={sponsor.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-center py-6 px-4 bg-glass backdrop-blur-sm border border-glass-border rounded-xl hover:opacity-70 transition-opacity"
                      >
                        <Image
                          src={sponsor.logo}
                          alt={sponsor.name}
                          width={160}
                          height={60}
                          className={`object-contain max-w-full ${config.logoSize}`}
                        />
                      </a>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>

          <div className="mt-20 pt-10 border-t border-border-subtle">
            <h3 className="font-display text-lg font-light text-fg">
              Become a sponsor
            </h3>
            <p className="mt-2 text-sm text-fg-muted max-w-md">
              Your support funds materials, travel, and competition registration.
            </p>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 mt-4 text-sm text-accent hover:opacity-70 transition-opacity"
            >
              <Mail className="w-3.5 h-3.5" />
              Get in touch
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
