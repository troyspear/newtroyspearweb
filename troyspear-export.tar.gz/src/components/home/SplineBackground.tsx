'use client'

import { Suspense, lazy, useCallback, useRef } from 'react'

const Spline = lazy(() => import('@splinetool/react-spline'))

function removeWatermark(container: HTMLDivElement | null) {
  if (!container) return
  const observer = new MutationObserver(() => {
    container.querySelectorAll('a[href*="spline"], [class*="watermark"], canvas ~ div, canvas ~ a').forEach((el) => {
      ;(el as HTMLElement).style.display = 'none'
    })
  })
  observer.observe(container, { childList: true, subtree: true })
}

export default function SplineBackground() {
  const containerRef = useRef<HTMLDivElement>(null)

  const onLoad = useCallback(() => {
    removeWatermark(containerRef.current)
  }, [])

  return (
    <div ref={containerRef} className="absolute inset-0 z-0 overflow-hidden" aria-hidden="true">
      <Suspense fallback={<div className="absolute inset-0 bg-page" />}>
        <Spline
          scene="https://prod.spline.design/uZEW89nK627-7QTa/scene.splinecode"
          style={{ pointerEvents: 'none', width: '100%', height: '100%' }}
          onLoad={onLoad}
        />
      </Suspense>
      <div className="absolute inset-0 bg-page/70" />
    </div>
  )
}
